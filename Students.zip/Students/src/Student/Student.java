package Student;

public class Student {
    
    public int NumberOfTest=3;
    protected String Name;
    protected int test[]= new int[NumberOfTest];
    protected String CourseGrade;
    int marks;

    public Student() {
        
    }
    public Student(String Name,int NumberOfTest) {
        
        this.Name = Name;
        this.NumberOfTest=NumberOfTest;
        this.NumberOfTest--;
    }

    public String getName() {
        return Name;
    }

    public String getCourseGrade() {
        return CourseGrade;
    }
    public int getTestScore(int marks){
    return marks;
        
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    public int setTestScore(int NumberOfTest,int TestScore){
        NumberOfTest--;
        test[NumberOfTest]=TestScore;
        marks=marks+test[NumberOfTest];
        return marks;
    }
   
}
