/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student;

/**
 *
 * @author fa16-bse-084
 */
public class UndergraduateStudent extends Student {
    
    @Override
    public String getCourseGrade(){
    if(super.marks<60){
    System.out.print("pass");
    }else{
    System.out.print("Fail");
    }
    
    return null;
    }
    
    
}
